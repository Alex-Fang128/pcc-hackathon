import { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { PCC, SPOTS } from './data';
import type { Point } from './geo';
export default function MapView({ selected, location, onSelect }: { selected: string; location: Point | null; onSelect: (id: string) => void }) {
  const element = useRef<HTMLDivElement>(null);
  const map = useRef<L.Map | null>(null);
  const markers = useRef<L.Marker[]>([]);
  const [tileError, setTileError] = useState(false);
  useEffect(() => {
    if (!element.current) return;
    const instance = L.map(element.current, { zoomControl: false, scrollWheelZoom: false }).fitBounds(L.latLngBounds(SPOTS.map(spot => [spot.lat, spot.lng] as [number, number])), { paddingTopLeft:[65,80], paddingBottomRight:[65,55], maxZoom:17 });
    map.current = instance;
    const tiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>' }).addTo(instance);
    tiles.on('tileerror', () => setTileError(true));
    tiles.on('tileload', () => setTileError(false));
    L.control.zoom({ position: 'bottomright' }).addTo(instance);
    L.polygon([[34.1413,-118.121],[34.1455,-118.121],[34.1455,-118.1164],[34.1413,-118.1164]], { color:'#398575', weight:1, dashArray:'5 7', fillColor:'#8dd6b5', fillOpacity:0.06, interactive:false }).addTo(instance);
    const resize = new ResizeObserver(() => {
      instance.invalidateSize();
      const width=element.current?.clientWidth??320;
      const side=Math.min(65,width*.16);
      instance.fitBounds(L.latLngBounds(SPOTS.map(spot=>[spot.lat,spot.lng] as [number,number])),{paddingTopLeft:[side,85],paddingBottomRight:[side,55],maxZoom:17,animate:false});
    });
    resize.observe(element.current);
    return () => { resize.disconnect(); instance.remove(); map.current = null; };
  }, []);
  useEffect(() => {
    const instance = map.current;
    if (!instance) return;
    markers.current.forEach(marker => marker.remove());
    markers.current = SPOTS.map((spot, i) => {
      const marker = L.marker([spot.lat, spot.lng], { icon: L.divIcon({ className:'spot-pin', html:`<span class="${spot.id === selected ? 'active' : ''}">${i + 1}</span>`, iconSize:[36,36], iconAnchor:[18,18] }), title: spot.name, alt: `Select ${spot.name}`, keyboard:true }).addTo(instance);
      const element = marker.getElement();
      element?.setAttribute('aria-label', `Select ${spot.name}`);
      element?.addEventListener('click', () => onSelect(spot.id));
      element?.addEventListener('keydown', event => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          onSelect(spot.id);
        }
      });
      return marker;
    });
  }, [selected, onSelect]);
  useEffect(() => {
    const instance = map.current;
    if (!instance || !location) return;
    const dot = L.circleMarker([location.lat, location.lng], { radius:7, color:'#fff', weight:3, fillColor:'#276de1', fillOpacity:1 }).addTo(instance).bindTooltip('Your reported location');
    return () => { dot.remove(); };
  }, [location]);
  return <><div className="leaflet-map" ref={element} aria-label="Interactive PCC map with three approximate candidate viewing spots" />{tileError && <div className="map-error" role="status">Map tiles unavailable. Candidate spots are still listed below.</div>}</>;
}
